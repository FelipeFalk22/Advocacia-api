module.exports = (models) => {
  // Importa os models
  const { AdvogadoModel } = require('./Advogado.js');
  const { ProcessoModel } = require('./Processo.js');

  // Verifica se ambos os modelos foram carregados
  if (AdvogadoModel && ProcessoModel) {
    // Um advogado possui vários processos
    if (!AdvogadoModel.associations.processos) {
      AdvogadoModel.hasMany(ProcessoModel, {
        foreignKey: 'id_advogado',
        as: 'processos',
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      });
    }

    // Cada processo pertence a um advogado
    if (!ProcessoModel.associations.advogado) {
      ProcessoModel.belongsTo(AdvogadoModel, {
        foreignKey: 'id_advogado',
        as: 'advogado',
      });
    }
  } else {
    console.warn('⚠️ Models Advogado ou Processo não foram carregados corretamente em relations.js');
  }
};
